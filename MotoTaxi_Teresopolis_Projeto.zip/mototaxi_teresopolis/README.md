# MotoTáxi Teresópolis — versão inicial

## O que está incluído
- Interface responsiva em português para moto-táxi e entregas.
- Tarifa mínima de R$ 8,00 e R$ 2,00 por km.
- Consulta de endereço via Nominatim/OpenStreetMap e rota via OSRM público.
- Estimativa de preço e envio do resumo para WhatsApp.
- Projeto-base Android com WebView para abrir a interface como app.

## WhatsApp
Configure seu número no arquivo `app/src/main/assets/index.html`, substituindo `55DDDNUMERO` na constante `WHATSAPP_NUMBER` pelo telefone com DDI e DDD, usando somente números.

## Como compilar APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `mototaxi_teresopolis` no Android Studio.
3. Aguarde a sincronização do Gradle e instale os componentes SDK sugeridos.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Limitações importantes desta versão
- Este ZIP é o código-fonte do projeto; não é um APK já compilado.
- A consulta de endereços e rotas precisa de internet e depende de serviços públicos, sem garantia de disponibilidade. Os serviços públicos têm políticas de uso e não devem ser tratados como infraestrutura garantida para uso comercial intenso.
- O cálculo usa a distância da rota retornada pelo serviço, arredondando o preço para centavos e aplicando tarifa mínima. Confirme se sua política comercial deseja cobrar por km iniciado, km exato ou outro arredondamento.
- O valor é estimativo. Desvios, espera, pedágios, retorno e condições especiais não estão incluídos.
- A área de Teresópolis é adicionada à busca dos endereços, mas a versão inicial ainda não bloqueia destinos fora da área de atendimento.
- O cliente precisa tocar em Enviar no WhatsApp. O app não envia mensagens silenciosamente.
- Antes de publicar, revise política de privacidade, termos, acessibilidade, marca/ícone e teste em aparelhos reais. Para operação comercial, considere um provedor de rotas com SLA e regras de uso adequadas.
